# EDICAL Cloudflare Production

Production-ready starter generated from EDICAL V6.

## Resources expected
- Worker: `edical-store`
- D1 binding: `DB`, database name `edical-store-db`
- R2 binding: `IMAGES`, bucket name `edical-store-images`
- Worker secret: `ADMIN_PASSWORD`

## Routes
- `/` Store
- `/admin.html` Admin
- `/api/*` Worker API
- `/media/*` R2 product images

## Before deploy
1. Create D1 database `edical-store-db`.
2. D1 Database ID is already configured: `eccdfdba-5bac-4cf7-9f46-0c53a1e1101f`.
3. Create R2 bucket `edical-store-images`.
4. Run migrations `0001_schema.sql` then `0002_seed.sql` on the remote D1 database.
5. Deploy Worker.
6. Add Worker secret `ADMIN_PASSWORD`.


## Important update
The Worker now auto-initializes the D1 schema and initial EDICAL data on first request.
You do NOT need to paste or execute the SQL migration files manually.
The migration files are retained only as a backup/reference.

## D1 diagnostics
- `/api/health` does not touch D1 and should always return `ok: true` if the Worker itself is alive.
- `/api/debug/db` initializes/checks D1 and returns the exact D1 error message if initialization fails.

## V8 shipping
Admin-configured delivery fee per governorate/zone; checkout live calculation; server-side verification; free-delivery threshold; shipping stored in order.

## Fresh deploy
Worker name forced to `edical-store-v8`.
Check `/api/health` for `shipping-v8`.
Check `/version.txt` for `EDICAL SHIPPING V8 FRESH DEPLOY`.
Uses the same D1 database and R2 bucket as the previous Worker.

## V10 Orders
- Product thumbnail visible directly on each order card, with a +N badge for multiple items.
- Native share creates a branded PNG receipt; text-share fallback included.
- Professional print receipt.
- Order editor for customer data, status, shipping fee and quantities.
- Quantity edits reconcile inventory server-side.
- DELETE removes the order from D1 and restores stock for non-delivered orders.

## V11 Premium Receipt
- Rebuilt print receipt from scratch for A5 portrait.
- Uses the real EDICAL logo from the admin UI.
- Brand accent strip uses EDICAL identity colors.
- Customer/status/meta sections redesigned as compact premium cards.
- Product rows include product thumbnails.
- Clear subtotal, shipping and strong final-total block.
- Premium branded footer with EDICAL contact details.
- Share PNG receipt redesigned to match the premium print language.

## V12 Orders + Receipt Fix
- Dashboard "latest orders" now binds Share / Print / Edit / Delete / Status / Details actions.
- Arrow-like details control replaced with explicit Arabic "التفاصيل".
- Receipt no longer contains product images; product names, quantity, unit price and line total remain.
- Print is now a single fixed receipt image fitted into one physical print page, independent of A5/Letter/A4 selection.
- Share PNG uses the same one-page text-only receipt design.

## V13 Order Actions
- Replaced per-render onclick bindings with one persistent delegated click/change system on document.
- Works for dashboard latest orders and the full Orders page, even after re-rendering.
- Added visible V13 badge to the admin header to confirm the correct static asset is deployed.
- Share now opens a generated receipt preview first; the actual native Share call happens on a fresh user tap.
- Print and share give immediate toast feedback.

## V14 Direct Actions
- Removed delegated order-action events entirely.
- Every order action now has a direct inline onclick.
- Order action functions are explicitly exported on window.
- Works after any innerHTML re-render because the handler is part of the generated button markup.
- Immediate button text feedback confirms the tap before async work starts.
- Status select uses direct inline onchange and a global handler.

## V15 Runtime Fix
- Receipt generation is synchronous: no image-load await before print/share.
- Existing loaded admin logo is drawn directly when available; text fallback otherwise.
- Share preview opens immediately from a prebuilt data URL/blob.
- Print receipt is generated before the popup document is written.
- Removed CSS.escape dependency from order editing.
- Delete confirmation is now an in-page modal instead of browser confirm().
- Order ID resolves from the closest order card first.
- Runtime errors are surfaced in the toast with the actual error message.
