# EDICAL Cloudflare Production

Production-ready starter generated from EDICAL V6.

## Resources expected
- Worker: `edical-store`
- D1 binding: `DB`, database name `edical-store-db`
- R2 binding: `IMAGES`, bucket name `edical-store-images`
- Worker secret: `ADMIN_PASSWORD`

## Routes
- `/` Store
- `/admin.html` Admin
- `/api/*` Worker API
- `/media/*` R2 product images

## Before deploy
1. Create D1 database `edical-store-db`.
2. D1 Database ID is already configured: `eccdfdba-5bac-4cf7-9f46-0c53a1e1101f`.
3. Create R2 bucket `edical-store-images`.
4. Run migrations `0001_schema.sql` then `0002_seed.sql` on the remote D1 database.
5. Deploy Worker.
6. Add Worker secret `ADMIN_PASSWORD`.


## Important update
The Worker now auto-initializes the D1 schema and initial EDICAL data on first request.
You do NOT need to paste or execute the SQL migration files manually.
The migration files are retained only as a backup/reference.

## D1 diagnostics
- `/api/health` does not touch D1 and should always return `ok: true` if the Worker itself is alive.
- `/api/debug/db` initializes/checks D1 and returns the exact D1 error message if initialization fails.

## V8 shipping
Admin-configured delivery fee per governorate/zone; checkout live calculation; server-side verification; free-delivery threshold; shipping stored in order.

## Fresh deploy
Worker name forced to `edical-store-v8`.
Check `/api/health` for `shipping-v8`.
Check `/version.txt` for `EDICAL SHIPPING V8 FRESH DEPLOY`.
Uses the same D1 database and R2 bucket as the previous Worker.

## V10 Orders
- Product thumbnail visible directly on each order card, with a +N badge for multiple items.
- Native share creates a branded PNG receipt; text-share fallback included.
- Professional print receipt.
- Order editor for customer data, status, shipping fee and quantities.
- Quantity edits reconcile inventory server-side.
- DELETE removes the order from D1 and restores stock for non-delivered orders.

## V11 Premium Receipt
- Rebuilt print receipt from scratch for A5 portrait.
- Uses the real EDICAL logo from the admin UI.
- Brand accent strip uses EDICAL identity colors.
- Customer/status/meta sections redesigned as compact premium cards.
- Product rows include product thumbnails.
- Clear subtotal, shipping and strong final-total block.
- Premium branded footer with EDICAL contact details.
- Share PNG receipt redesigned to match the premium print language.
