
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
const bad=(error,status=400)=>json({error},status);
const INITIAL_STATE={"categories":[{"id":"serum","name_ar":"السيرومات","name_en":"Serums","color":"#F7941D","active":true,"sort":1},{"id":"soap","name_ar":"الصوابين","name_en":"Soaps","color":"#FFF200","active":true,"sort":2},{"id":"cream","name_ar":"الكريمات","name_en":"Creams","color":"#EC008C","active":true,"sort":3},{"id":"toothpaste","name_ar":"معاجين الأسنان","name_en":"Toothpaste","color":"#00A99D","active":true,"sort":4}],"settings":{"whatsapp":"9647739477773","whatsapp_display":"07739477773","instagram":"edical.uk","facebook":"edical.uk","free_shipping":60000,"currency":"IQD","store_name":"EDICAL London","delivery_note_ar":"الدفع عند الاستلام. تظهر أجرة التوصيل بعد اختيار المحافظة.","delivery_note_en":"Cash on delivery. Delivery fee appears after selecting your governorate.","shipping_rates":[{"id":"baghdad","name_ar":"بغداد","name_en":"Baghdad","fee":"","active":true},{"id":"anbar","name_ar":"الأنبار","name_en":"Anbar","fee":"","active":true},{"id":"basra","name_ar":"البصرة","name_en":"Basra","fee":"","active":true},{"id":"nineveh","name_ar":"نينوى","name_en":"Nineveh","fee":"","active":true},{"id":"erbil","name_ar":"أربيل","name_en":"Erbil","fee":"","active":true},{"id":"karbala","name_ar":"كربلاء","name_en":"Karbala","fee":"","active":true},{"id":"najaf","name_ar":"النجف","name_en":"Najaf","fee":"","active":true},{"id":"diyala","name_ar":"ديالى","name_en":"Diyala","fee":"","active":true},{"id":"kirkuk","name_ar":"كركوك","name_en":"Kirkuk","fee":"","active":true},{"id":"salah-al-din","name_ar":"صلاح الدين","name_en":"Salah al-Din","fee":"","active":true},{"id":"dhi-qar","name_ar":"ذي قار","name_en":"Dhi Qar","fee":"","active":true},{"id":"babil","name_ar":"بابل","name_en":"Babil","fee":"","active":true},{"id":"wasit","name_ar":"واسط","name_en":"Wasit","fee":"","active":true},{"id":"maysan","name_ar":"ميسان","name_en":"Maysan","fee":"","active":true},{"id":"muthanna","name_ar":"المثنى","name_en":"Muthanna","fee":"","active":true},{"id":"qadisiyah","name_ar":"القادسية","name_en":"Al-Qadisiyah","fee":"","active":true},{"id":"duhok","name_ar":"دهوك","name_en":"Duhok","fee":"","active":true},{"id":"sulaymaniyah","name_ar":"السليمانية","name_en":"Sulaymaniyah","fee":"","active":true}]},"announcements":[{"id":"ann1","text_ar":"توصيل مجاني للطلبات فوق 60,000 د.ع","text_en":"Free delivery on orders over 60,000 IQD","active":true,"color":"green","start":"","end":"","dismissible":true},{"id":"ann2","text_ar":"للتواصل المباشر عبر واتساب: 07739477773","text_en":"Direct WhatsApp contact: 07739477773","active":true,"color":"teal","start":"","end":"","dismissible":true}],"offers":[{"id":"off1","title_ar":"خصم على المنتجات المختارة","title_en":"Discount on selected products","type":"percent","value":20,"target":"selected","targetValue":"","active":true,"start":"","end":"","color":"orange","subtitle_ar":"يمكن تخصيص هذا العرض لأي مجموعة منتجات.","subtitle_en":"This offer can target any selected products."},{"id":"off2","title_ar":"توصيل مجاني فوق 60,000 د.ع","title_en":"Free delivery over 60,000 IQD","type":"shipping","value":60000,"target":"all","targetValue":"","active":true,"start":"","end":"","color":"green","subtitle_ar":"عرض توصيل للطلبات المؤهلة.","subtitle_en":"Delivery offer for eligible orders."},{"id":"off3","title_ar":"باقة EDICAL مخصصة","title_en":"Custom EDICAL bundle","type":"bundle","value":0,"target":"selected","targetValue":"","active":false,"start":"","end":"","color":"purple","subtitle_ar":"اجمع عدة منتجات بسعر خاص.","subtitle_en":"Combine selected products at a special price."}],"campaigns":[{"id":"cmp1","title_ar":"حملة EDICAL الموسمية","title_en":"EDICAL Seasonal Campaign","subtitle_ar":"بانر رئيسي للحملات والعروض الموسمية.","subtitle_en":"A main banner for seasonal campaigns and offers.","active":false,"start":"","end":"","placement":"home","image":"","offerId":"off1"}],"home":{"hero_title_ar":"عناية تعرف بشرتك.","hero_title_en":"Skincare that knows your skin.","hero_text_ar":"تجربة تسوق بسيطة لمنتجات EDICAL، مرتبة حسب النوع ومن دون قوائم معقدة.","hero_text_en":"A simple way to discover EDICAL products by type, without complicated menus.","hero_button_ar":"تسوق المنتجات","hero_button_en":"Shop products","hero_image":"","featured_limit":4}};
const INITIAL_PRODUCTS=[{"id":1,"cat":"serum","name_en":"Vitamin C Serum","name_ar":"سيروم فيتامين C","price":28000,"stock":20,"featured":true,"img":"/assets/products/p1-9ad363622a.jpg","desc_ar":"إشراقة وعناية يومية للبشرة.","desc_en":"Daily radiance skincare.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p1-9ad363622a.jpg"]},{"id":2,"cat":"serum","name_en":"EDICAL Serum 02","name_ar":"سيروم EDICAL 02","price":0,"stock":20,"featured":true,"img":"/assets/products/p2-2e0e979b41.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p2-2e0e979b41.jpg"]},{"id":3,"cat":"serum","name_en":"EDICAL Serum 03","name_ar":"سيروم EDICAL 03","price":0,"stock":20,"featured":false,"img":"/assets/products/p2-2e0e979b41.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p2-2e0e979b41.jpg"]},{"id":4,"cat":"serum","name_en":"EDICAL Serum 04","name_ar":"سيروم EDICAL 04","price":0,"stock":20,"featured":false,"img":"/assets/products/p2-2e0e979b41.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p2-2e0e979b41.jpg"]},{"id":5,"cat":"serum","name_en":"EDICAL Serum 05","name_ar":"سيروم EDICAL 05","price":0,"stock":20,"featured":false,"img":"/assets/products/p2-2e0e979b41.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p2-2e0e979b41.jpg"]},{"id":6,"cat":"soap","name_en":"EDICAL Soap 01","name_ar":"صابونة EDICAL 01","price":0,"stock":20,"featured":true,"img":"/assets/products/p6-38d7074c1c.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p6-38d7074c1c.jpg"]},{"id":7,"cat":"soap","name_en":"EDICAL Soap 02","name_ar":"صابونة EDICAL 02","price":0,"stock":20,"featured":false,"img":"/assets/products/p7-1c2c8bd7df.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p7-1c2c8bd7df.jpg"]},{"id":8,"cat":"soap","name_en":"EDICAL Soap 03","name_ar":"صابونة EDICAL 03","price":0,"stock":20,"featured":false,"img":"/assets/products/p8-d2b2201cd6.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p8-d2b2201cd6.jpg"]},{"id":9,"cat":"soap","name_en":"EDICAL Soap 04","name_ar":"صابونة EDICAL 04","price":0,"stock":20,"featured":false,"img":"/assets/products/p9-5eb0b3ed2d.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p9-5eb0b3ed2d.jpg"]},{"id":10,"cat":"soap","name_en":"EDICAL Soap 05","name_ar":"صابونة EDICAL 05","price":0,"stock":20,"featured":false,"img":"/assets/products/p6-38d7074c1c.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p6-38d7074c1c.jpg"]},{"id":11,"cat":"cream","name_en":"EDICAL Cream 01","name_ar":"كريم EDICAL 01","price":0,"stock":20,"featured":true,"img":"/assets/products/p8-d2b2201cd6.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p8-d2b2201cd6.jpg"]},{"id":12,"cat":"cream","name_en":"EDICAL Cream 02","name_ar":"كريم EDICAL 02","price":0,"stock":20,"featured":false,"img":"/assets/products/p7-1c2c8bd7df.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p7-1c2c8bd7df.jpg"]},{"id":13,"cat":"cream","name_en":"EDICAL Cream 03","name_ar":"كريم EDICAL 03","price":0,"stock":20,"featured":false,"img":"/assets/products/p6-38d7074c1c.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p6-38d7074c1c.jpg"]},{"id":14,"cat":"toothpaste","name_en":"EDICAL Toothpaste 01","name_ar":"معجون EDICAL 01","price":0,"stock":20,"featured":true,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]},{"id":15,"cat":"toothpaste","name_en":"EDICAL Toothpaste 02","name_ar":"معجون EDICAL 02","price":0,"stock":20,"featured":false,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]},{"id":16,"cat":"toothpaste","name_en":"EDICAL Toothpaste 03","name_ar":"معجون EDICAL 03","price":0,"stock":20,"featured":false,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]},{"id":17,"cat":"toothpaste","name_en":"EDICAL Toothpaste 04","name_ar":"معجون EDICAL 04","price":0,"stock":20,"featured":false,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]},{"id":18,"cat":"toothpaste","name_en":"EDICAL Toothpaste 05","name_ar":"معجون EDICAL 05","price":0,"stock":20,"featured":false,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]},{"id":19,"cat":"toothpaste","name_en":"EDICAL Toothpaste 06","name_ar":"معجون EDICAL 06","price":0,"stock":20,"featured":false,"img":"/assets/products/p14-5e437fa0a3.jpg","desc_ar":"تفاصيل المنتج تُضاف من الكتالوج الرسمي.","desc_en":"Product details will be added from the official catalogue.","compare_price":0,"status":"published","benefits_ar":[],"benefits_en":[],"ingredients_ar":[],"ingredients_en":[],"how_ar":"","how_en":"","images":["/assets/products/p14-5e437fa0a3.jpg"]}];
const STATE_KEYS=new Set(['categories','settings','announcements','offers','campaigns','home']);


let __ready=false;
async function ensureDatabase(env){
  if(__ready)return;
  const schema=[
    `CREATE TABLE IF NOT EXISTS state (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      cat TEXT NOT NULL DEFAULT '',
      name_ar TEXT NOT NULL DEFAULT '',
      name_en TEXT NOT NULL DEFAULT '',
      price INTEGER NOT NULL DEFAULT 0,
      compare_price INTEGER NOT NULL DEFAULT 0,
      stock INTEGER NOT NULL DEFAULT 0,
      sku TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'draft',
      featured INTEGER NOT NULL DEFAULT 0,
      sort_order INTEGER NOT NULL DEFAULT 0,
      data TEXT NOT NULL DEFAULT '{}',
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE INDEX IF NOT EXISTS idx_products_status_sort ON products(status, sort_order)`,
    `CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      phone TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'received',
      total INTEGER NOT NULL DEFAULT 0,
      data TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(phone)`,
    `CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC)`
  ];
  await env.DB.batch(schema.map(q=>env.DB.prepare(q)));

  const c=await env.DB.prepare('SELECT COUNT(*) AS n FROM products').first();
  if(!c || Number(c.n)===0){
    await syncProducts(env,INITIAL_PRODUCTS);
  }
  for(const [k,v] of Object.entries(INITIAL_STATE)){
    const row=await env.DB.prepare('SELECT key FROM state WHERE key=?').bind(k).first();
    if(!row) await statePut(env,k,v);
  }
  __ready=true;
}

function cleanSecret(v){return String(v??'').trim()}
function adminOK(req,env){
  const supplied=cleanSecret(req.headers.get('x-admin-password'));
  const configured=cleanSecret(env.ADMIN_PASSWORD);
  return !!configured && supplied===configured;
}
async function stateGet(env,key){
  const row=await env.DB.prepare('SELECT value FROM state WHERE key=?').bind(key).first();
  return row?JSON.parse(row.value):null;
}
async function statePut(env,key,value){
  await env.DB.prepare(`INSERT INTO state(key,value,updated_at) VALUES(?,?,datetime('now'))
    ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=datetime('now')`)
    .bind(key,JSON.stringify(value)).run();
}
async function listProducts(env,admin=false){
  const q=admin?'SELECT * FROM products ORDER BY sort_order,id':'SELECT * FROM products WHERE status=? ORDER BY sort_order,id';
  const res=admin?await env.DB.prepare(q).all():await env.DB.prepare(q).bind('published').all();
  return res.results.map(r=>{
    let x={};try{x=JSON.parse(r.data||'{}')}catch{}
    return {...x,id:isNaN(Number(r.id))?r.id:Number(r.id),cat:r.cat,name_ar:r.name_ar,name_en:r.name_en,
      price:r.price,compare_price:r.compare_price,stock:r.stock,sku:r.sku,status:r.status,featured:!!r.featured,sort_order:r.sort_order};
  });
}
async function syncProducts(env,items){
  if(!Array.isArray(items))throw new Error('invalid_products');
  const stmts=[env.DB.prepare('DELETE FROM products')];
  items.forEach((p,i)=>{
    const id=String(p.id??Date.now()+i);
    const extra={...p};['id','cat','name_ar','name_en','price','compare_price','stock','sku','status','featured','sort_order'].forEach(k=>delete extra[k]);
    stmts.push(env.DB.prepare(`INSERT INTO products
      (id,cat,name_ar,name_en,price,compare_price,stock,sku,status,featured,sort_order,data,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'))`)
      .bind(id,p.cat||'',p.name_ar||'',p.name_en||'',Number(p.price)||0,Number(p.compare_price)||0,Number(p.stock)||0,p.sku||'',p.status||'draft',p.featured?1:0,Number(p.sort_order??i),JSON.stringify(extra)));
  });
  await env.DB.batch(stmts);
}
async function bootstrap(env,admin=false){
  const keys=['categories','settings','announcements','offers','campaigns','home'];
  const pairs=await Promise.all(keys.map(async k=>[k,await stateGet(env,k)]));
  const out=Object.fromEntries(pairs);
  out.products=await listProducts(env,admin);
  if(admin){
    const r=await env.DB.prepare('SELECT data FROM orders ORDER BY created_at DESC LIMIT 500').all();
    out.orders=r.results.map(x=>JSON.parse(x.data));
  }
  return out;
}
function statusLabel(s){
 const ar={received:'تم استلام الطلب',new:'طلب جديد',confirmed:'تم التأكيد',preparing:'جاري التجهيز',shipped:'خرج للتوصيل',delivered:'تم التسليم',cancelled:'ملغي'};
 const en={received:'Order received',new:'New',confirmed:'Confirmed',preparing:'Preparing',shipped:'Out for delivery',delivered:'Delivered',cancelled:'Cancelled'};
 return {status_ar:ar[s]||s,status_en:en[s]||s};
}
async function createOrder(req,env){
  const body=await req.json().catch(()=>null);
  if(!body||!Array.isArray(body.items)||!body.items.length||!body.customer)return bad('invalid_order');
  const c=body.customer;
  if(!String(c.phone||'').trim()||!String(c.fullName||c.name||'').trim())return bad('missing_customer_fields');
  const items=[];let subtotal=0;const updates=[];
  for(const line of body.items){
    const qty=Math.max(1,Math.min(99,Number(line.qty)||1));
    const p=await env.DB.prepare('SELECT * FROM products WHERE id=? AND status=?').bind(String(line.id),'published').first();
    if(!p)return bad('product_not_found');
    if(Number(p.stock)<qty)return bad('out_of_stock');
    const lineTotal=Number(p.price)*qty;subtotal+=lineTotal;
    let pdata={};try{pdata=JSON.parse(p.data||'{}')}catch{}
    const orderImg=pdata.img||(Array.isArray(pdata.images)&&pdata.images[0])||'';
    items.push({
      id:isNaN(Number(p.id))?p.id:Number(p.id),
      name_ar:p.name_ar,name_en:p.name_en,
      qty,price:Number(p.price),total:lineTotal,
      img:orderImg,sku:p.sku||''
    });
    updates.push(env.DB.prepare("UPDATE products SET stock=stock-?,updated_at=datetime(\'now\') WHERE id=? AND stock>=?").bind(qty,String(p.id),qty));
  }
  const settings=await stateGet(env,'settings')||{};
  const rates=Array.isArray(settings.shipping_rates)?settings.shipping_rates:[];
  const zone=rates.find(z=>z&&z.active!==false&&String(z.id)===String(c.gov||''));
  if(!zone)return bad('shipping_zone_not_found');
  const freeAt=Math.max(0,Number(settings.free_shipping)||0);
  let shippingFee;
  if(freeAt>0&&subtotal>=freeAt){shippingFee=0}
  else{
    if(zone.fee===''||zone.fee==null||!Number.isFinite(Number(zone.fee)))return bad('shipping_not_configured');
    shippingFee=Math.max(0,Number(zone.fee)||0);
  }
  c.governorate=c.governorate||zone.name_ar||zone.name_en||c.gov;
  const total=subtotal+shippingFee;
  const id='ED-'+Date.now().toString().slice(-7);
  const order={id,status:'received',createdAt:new Date().toISOString(),customer:c,items,subtotal,shipping_fee:shippingFee,shipping_zone:{id:zone.id,name_ar:zone.name_ar||'',name_en:zone.name_en||'',fee:shippingFee},total};
  updates.push(env.DB.prepare("INSERT INTO orders(id,phone,status,total,data,created_at,updated_at) VALUES(?,?,?,?,?,datetime(\'now\'),datetime(\'now\'))")
    .bind(id,String(c.phone),order.status,total,JSON.stringify(order)));
  await env.DB.batch(updates);
  return json({id,subtotal,shipping_fee:shippingFee,total});
}
async function route(req,env){
  const u=new URL(req.url),p=u.pathname;
  if(p==='/api/health')return json({ok:true,service:'edical',version:'receipt-v11'});
  if(p==='/api/auth/diagnostic'){
    const configured=cleanSecret(env.ADMIN_PASSWORD);
    const supplied=cleanSecret(req.headers.get('x-admin-password'));
    return json({
      ok:true,
      version:'receipt-v11',
      secret_configured:!!configured,
      password_match:!!configured && !!supplied && configured===supplied
    });
  }
  if(p==='/api/debug/db'){
    try{
      await ensureDatabase(env);
      const tables=await env.DB.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all();
      const count=await env.DB.prepare("SELECT COUNT(*) AS n FROM products").first();
      return json({ok:true,tables:tables.results,products:Number(count?.n||0)});
    }catch(e){
      console.error('D1 init error',e);
      return json({ok:false,error:String(e?.message||e),cause:String(e?.cause?.message||'')},500);
    }
  }
  await ensureDatabase(env);
  if(p==='/api/bootstrap'&&req.method==='GET')return json(await bootstrap(env,false));
  if(p==='/api/orders'&&req.method==='POST')return createOrder(req,env);
  if(p==='/api/orders/track'&&req.method==='GET'){
    const id=(u.searchParams.get('id')||'').toUpperCase(),phone=u.searchParams.get('phone')||'';
    const r=await env.DB.prepare('SELECT id,status FROM orders WHERE id=? AND phone=?').bind(id,phone).first();
    if(!r)return bad('not_found',404);
    return json({id:r.id,status:r.status,...statusLabel(r.status)});
  }
  if(p.startsWith('/media/')&&req.method==='GET'){
    const key=decodeURIComponent(p.slice(7));const obj=await env.IMAGES.get(key);
    if(!obj)return new Response('Not found',{status:404});
    const h=new Headers();obj.writeHttpMetadata(h);h.set('etag',obj.httpEtag);h.set('cache-control','public,max-age=31536000,immutable');
    return new Response(obj.body,{headers:h});
  }
  if(p.startsWith('/api/admin/')){
    if(!adminOK(req,env))return bad('unauthorized',401);
    if(p==='/api/admin/bootstrap'&&req.method==='GET')return json(await bootstrap(env,true));
    if(p.startsWith('/api/admin/state/')&&req.method==='PUT'){
      const key=decodeURIComponent(p.slice('/api/admin/state/'.length));
      const value=await req.json();
      if(key==='products')await syncProducts(env,value);
      else if(STATE_KEYS.has(key))await statePut(env,key,value);
      else return bad('unknown_state');
      return json({ok:true});
    }
    if(p==='/api/admin/upload'&&req.method==='POST'){
      const form=await req.formData();const f=form.get('file');
      if(!(f instanceof File))return bad('file_required');
      if(!String(f.type||'').startsWith('image/'))return bad('images_only');
      if(f.size>8*1024*1024)return bad('file_too_large');
      const ext=(f.name.split('.').pop()||'jpg').replace(/[^a-zA-Z0-9]/g,'').toLowerCase();
      const key=`products/${Date.now()}-${crypto.randomUUID()}.${ext}`;
      await env.IMAGES.put(key,f.stream(),{httpMetadata:{contentType:f.type||'image/jpeg'}});
      return json({ok:true,url:'/media/'+encodeURIComponent(key)});
    }
    if(p.startsWith('/api/admin/orders/')&&req.method==='PATCH'){
      const id=decodeURIComponent(p.slice('/api/admin/orders/'.length));
      const body=await req.json().catch(()=>({}));
      const allowed=new Set(['received','new','confirmed','preparing','shipped','delivered','cancelled']);
      const row=await env.DB.prepare('SELECT data FROM orders WHERE id=?').bind(id).first();
      if(!row)return bad('not_found',404);
      const o=JSON.parse(row.data);

      // Lightweight status-only update.
      if(body.status && !body.customer && !body.items && body.shipping_fee===undefined){
        if(!allowed.has(body.status))return bad('invalid_status');
        o.status=body.status;o.updatedAt=new Date().toISOString();
        await env.DB.prepare("UPDATE orders SET status=?,data=?,updated_at=datetime('now') WHERE id=?")
          .bind(o.status,JSON.stringify(o),id).run();
        return json({ok:true,order:o});
      }

      const nextStatus=body.status||o.status||'received';
      if(!allowed.has(nextStatus))return bad('invalid_status');

      const oldItems=Array.isArray(o.items)?o.items:[];
      const requested=Array.isArray(body.items)?body.items:oldItems;
      const nextItems=[];
      const stockOps=[];

      for(const oldItem of oldItems){
        const reqItem=requested.find(x=>String(x.id)===String(oldItem.id));
        const oldQty=Math.max(0,Number(oldItem.qty)||0);
        const newQty=reqItem ? Math.max(0,Math.min(99,Number(reqItem.qty)||0)) : oldQty;
        const delta=newQty-oldQty;

        if(delta>0){
          const pRow=await env.DB.prepare('SELECT stock FROM products WHERE id=?').bind(String(oldItem.id)).first();
          if(!pRow || Number(pRow.stock)<delta)return bad('insufficient_stock');
          stockOps.push(env.DB.prepare("UPDATE products SET stock=stock-?,updated_at=datetime('now') WHERE id=? AND stock>=?")
            .bind(delta,String(oldItem.id),delta));
        }else if(delta<0){
          stockOps.push(env.DB.prepare("UPDATE products SET stock=stock+?,updated_at=datetime('now') WHERE id=?")
            .bind(Math.abs(delta),String(oldItem.id)));
        }

        if(newQty>0){
          const price=Math.max(0,Number(oldItem.price)||0);
          nextItems.push({...oldItem,qty:newQty,total:price*newQty});
        }
      }

      if(!nextItems.length)return bad('order_requires_item');

      const customer={...(o.customer||{}),...(body.customer||{})};
      customer.name=String(customer.name||customer.fullName||'').trim();
      customer.fullName=customer.fullName||customer.name;
      customer.phone=String(customer.phone||'').trim();
      if(!customer.name||!customer.phone)return bad('missing_customer_fields');

      const subtotal=nextItems.reduce((s,i)=>s+(Number(i.total)||0),0);
      const shippingFee=body.shipping_fee===undefined
        ? Math.max(0,Number(o.shipping_fee)||0)
        : Math.max(0,Number(body.shipping_fee)||0);
      const total=subtotal+shippingFee;

      const updated={
        ...o,
        status:nextStatus,
        customer,
        items:nextItems,
        subtotal,
        shipping_fee:shippingFee,
        total,
        updatedAt:new Date().toISOString()
      };
      if(updated.shipping_zone)updated.shipping_zone={...updated.shipping_zone,fee:shippingFee};

      stockOps.push(env.DB.prepare("UPDATE orders SET phone=?,status=?,total=?,data=?,updated_at=datetime('now') WHERE id=?")
        .bind(customer.phone,nextStatus,total,JSON.stringify(updated),id));
      await env.DB.batch(stockOps);
      return json({ok:true,order:updated});
    }
    if(p.startsWith('/api/admin/orders/')&&req.method==='DELETE'){
      const id=decodeURIComponent(p.slice('/api/admin/orders/'.length));
      const row=await env.DB.prepare('SELECT data FROM orders WHERE id=?').bind(id).first();
      if(!row)return bad('not_found',404);
      const o=JSON.parse(row.data);
      const ops=[];

      // A non-delivered order consumed stock at checkout, so restore it on deletion.
      if(o.status!=='delivered'){
        for(const item of (Array.isArray(o.items)?o.items:[])){
          const qty=Math.max(0,Number(item.qty)||0);
          if(qty>0)ops.push(env.DB.prepare("UPDATE products SET stock=stock+?,updated_at=datetime('now') WHERE id=?")
            .bind(qty,String(item.id)));
        }
      }
      ops.push(env.DB.prepare('DELETE FROM orders WHERE id=?').bind(id));
      await env.DB.batch(ops);
      return json({ok:true,restocked:o.status!=='delivered'});
    }
  }
  return env.ASSETS.fetch(req);
}
export default {async fetch(req,env){try{return await route(req,env)}catch(e){console.error('EDICAL Worker error',e);return json({error:'server_error',detail:String(e?.message||e)},500)}}};
